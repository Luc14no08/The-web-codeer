// =============================================
// 1) ELEMENTOS DEL HTML
// =============================================

// Capturamos los elementos que vamos a usar con JavaScript
const imagen = document.getElementById('imagen');
const nombre = document.getElementById('nombreImagen');
const btnAnterior = document.getElementById('anterior');
const btnSiguiente = document.getElementById('siguiente');

// =============================================
// 2) Lista de imágenes de la galería
// =============================================

// Array con los nombres de las imágenes y sus títulos
const galeria = [
{ src: 'Imágenes/Mario SSBU.jpg', nombre: 'Mario' },
{ src: 'Imágenes/Pac-Man SSBU.jpg', nombre: 'Pac-Man' },
{ src: 'Imágenes/Sonic SSBU.jpg', nombre: 'Sonic' },
{ src: 'Imágenes/Kirby SSBU.jpg', nombre: 'Kirby' },
{ src: 'Imágenes/Mega Man SSBU.jpg', nombre: 'Mega Man' },
{ src: 'Imágenes/Link SSBU.jpg', nombre: 'Link' },
{ src: 'Imágenes/Steve SSBU.jpg', nombre: 'Steve' },
{ src: 'Imágenes/Mr Game & Watch SSBU.jpg', nombre: 'Mr Game & Watch' }
];

// Agregué más imágenes

let actual = 0; // posición actual en la galería

// =============================================
// 3) FUNCIÓN PARA MOSTRAR LA IMAGEN ACTUAL
// =============================================

function mostrarImagen() {
imagen.src = galeria[actual].src;
imagen.alt = galeria[actual].nombre;
nombre.textContent = galeria[actual].nombre;
}

// =============================================
// 4) EVENTOS DE LOS BOTONES
// =============================================

btnAnterior.addEventListener('click', () => {
// Si estamos en la primera, volvemos al final
actual = (actual - 1 + galeria.length) % galeria.length;
mostrarImagen();
});

btnSiguiente.addEventListener('click', () => {
// Si estamos en la última, volvemos al principio
actual = (actual + 1) % galeria.length;
mostrarImagen();

});

// =============================================
// 5) MOSTRAR LA PRIMERA IMAGEN AL CARGAR
// =============================================

mostrarImagen();